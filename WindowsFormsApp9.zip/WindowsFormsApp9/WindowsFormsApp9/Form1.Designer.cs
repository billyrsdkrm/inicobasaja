﻿namespace WindowsFormsApp9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButton1_Muncul = new System.Windows.Forms.RadioButton();
            this.radioButton2_Hilang = new System.Windows.Forms.RadioButton();
            this.label1_wordcount = new System.Windows.Forms.Label();
            this.textBox1_nama = new System.Windows.Forms.TextBox();
            this.button1_change = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2_displayname = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // radioButton1_Muncul
            // 
            this.radioButton1_Muncul.AutoSize = true;
            this.radioButton1_Muncul.Location = new System.Drawing.Point(12, 67);
            this.radioButton1_Muncul.Name = "radioButton1_Muncul";
            this.radioButton1_Muncul.Size = new System.Drawing.Size(60, 17);
            this.radioButton1_Muncul.TabIndex = 0;
            this.radioButton1_Muncul.Text = "Muncul";
            this.radioButton1_Muncul.UseVisualStyleBackColor = true;
            this.radioButton1_Muncul.CheckedChanged += new System.EventHandler(this.radioButton1_Muncul_CheckedChanged);
            // 
            // radioButton2_Hilang
            // 
            this.radioButton2_Hilang.AutoSize = true;
            this.radioButton2_Hilang.Location = new System.Drawing.Point(104, 67);
            this.radioButton2_Hilang.Name = "radioButton2_Hilang";
            this.radioButton2_Hilang.Size = new System.Drawing.Size(55, 17);
            this.radioButton2_Hilang.TabIndex = 1;
            this.radioButton2_Hilang.Text = "Hilang";
            this.radioButton2_Hilang.UseVisualStyleBackColor = true;
            this.radioButton2_Hilang.CheckedChanged += new System.EventHandler(this.radioButton1_Hilang_CheckedChanged);
            // 
            // label1_wordcount
            // 
            this.label1_wordcount.AutoSize = true;
            this.label1_wordcount.Location = new System.Drawing.Point(84, 123);
            this.label1_wordcount.Name = "label1_wordcount";
            this.label1_wordcount.Size = new System.Drawing.Size(27, 13);
            this.label1_wordcount.TabIndex = 2;
            this.label1_wordcount.Text = "halo";
            this.label1_wordcount.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1_nama
            // 
            this.textBox1_nama.Location = new System.Drawing.Point(12, 12);
            this.textBox1_nama.Name = "textBox1_nama";
            this.textBox1_nama.Size = new System.Drawing.Size(110, 20);
            this.textBox1_nama.TabIndex = 3;
            this.textBox1_nama.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1_change
            // 
            this.button1_change.Location = new System.Drawing.Point(12, 38);
            this.button1_change.Name = "button1_change";
            this.button1_change.Size = new System.Drawing.Size(75, 23);
            this.button1_change.TabIndex = 4;
            this.button1_change.Text = "Change";
            this.button1_change.UseVisualStyleBackColor = true;
            this.button1_change.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Jumlah Huruf";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label2_displayname
            // 
            this.label2_displayname.AutoSize = true;
            this.label2_displayname.Font = new System.Drawing.Font("Cooper Black", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_displayname.Location = new System.Drawing.Point(12, 87);
            this.label2_displayname.Name = "label2_displayname";
            this.label2_displayname.Size = new System.Drawing.Size(96, 31);
            this.label2_displayname.TabIndex = 6;
            this.label2_displayname.Text = "label2";
            this.label2_displayname.Click += new System.EventHandler(this.label2_displayname_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 368);
            this.Controls.Add(this.label2_displayname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1_change);
            this.Controls.Add(this.textBox1_nama);
            this.Controls.Add(this.label1_wordcount);
            this.Controls.Add(this.radioButton2_Hilang);
            this.Controls.Add(this.radioButton1_Muncul);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton1_Muncul;
        private System.Windows.Forms.RadioButton radioButton2_Hilang;
        private System.Windows.Forms.Label label1_wordcount;
        private System.Windows.Forms.TextBox textBox1_nama;
        private System.Windows.Forms.Button button1_change;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2_displayname;
    }
}

