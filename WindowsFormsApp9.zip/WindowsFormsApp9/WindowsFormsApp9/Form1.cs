﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_Muncul_CheckedChanged(object sender, EventArgs e)
        {
            /*if (radioButton1_Muncul.Checked == true)
            {
                label2_displayname.Visible = true;
                label2_displayname.Text = textBox1_nama.Text;
                label1_wordcount.Text = Convert.ToString(textBox1_nama.Text.Length);
            }*/
        }
        private void radioButton1_Hilang_CheckedChanged(object sender, EventArgs e)
        {
           /* if (radioButton2_Hilang.Checked == true)
            {
                label2_displayname.Visible = false;
                label2_displayname.Text = textBox1_nama.Text;
                label1_wordcount.Text = Convert.ToString(textBox1_nama.Text.Length);
            }*/
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*label2_displayname.Text = textBox1_nama.Text;
            label1_wordcount.Text = Convert.ToString(textBox1_nama.Text.Length);*/
            if (button1_change.Text == textBox1_nama.Text) 
            {
                MessageBox.Show("Silahkan Diisi");
            }
            else
            {
                if (radioButton1_Muncul.Checked == true)
                {
                    label2_displayname.Visible = true;
                    label2_displayname.Text = textBox1_nama.Text;
                    label1_wordcount.Text = Convert.ToString(textBox1_nama.Text.Length);
                }
                else if (radioButton2_Hilang.Checked == true)
                {
                    label2_displayname.Visible = false;
                    label2_displayname.Text = textBox1_nama.Text;
                    label1_wordcount.Text = Convert.ToString(textBox1_nama.Text.Length);
                }
                else
                {
                    MessageBox.Show("Silahkan Pilih Mode");
                }
            }
            
        }

        private void label2_displayname_Click(object sender, EventArgs e)
        {

        }
    }
}
